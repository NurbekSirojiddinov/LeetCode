public class HelloGoodbye {
    public HelloGoodbye(){}
    private HelloGoodbye(String string1, String string2){
        System.out.println("Hello " + string1 +" and " + string2);
        System.out.println("Goodbye " + string2 + " and " + string1);
    }
}
