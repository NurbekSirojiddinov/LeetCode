public class HelloGoodbye {
    private HelloGoodbye(String string1, String string2){
        System.out.println("Hello " + string1 +" and " + string2);
        System.out.println("Goodbye " + string2 + " and " + string1);
    }
    public static void main(String[] args) {
        System.out.println("Hello,Goodbye");
    }
}
